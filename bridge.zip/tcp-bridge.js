#!/usr/bin/env node
// Tiny WebSocket-to-TCP bridge for Modbus TCP.
//
// Browsers can't open raw TCP, so we run this small bridge that accepts
// WebSocket connections and pipes their binary frames to a real TCP socket.
//
//   Browser → ws://localhost:8765/?host=192.168.0.10&port=502 → bridge → TCP host:port
//
// Usage:
//   node tcp-bridge.js                  (defaults to :8765, any host allowed)
//   node tcp-bridge.js --port 9000      (custom WebSocket port)
//   node tcp-bridge.js --allow 192.168. (restrict targets to a prefix)
//
// Requires Node.js 18+ and the 'ws' package:
//   npm install ws

const net = require('net');
const url = require('url');

let WebSocketServer;
try {
  WebSocketServer = require('ws').WebSocketServer;
} catch (e) {
  console.error("Missing dependency. Run:\n  npm install ws\nin the bridge/ folder first.");
  process.exit(1);
}

// ----- Args -----
const args = process.argv.slice(2);
function arg(name, def) {
  const i = args.indexOf('--' + name);
  return i >= 0 ? args[i + 1] : def;
}
const WS_PORT = parseInt(arg('port', '8765'), 10);
const WS_HOST = arg('bind', '127.0.0.1');
const ALLOW = arg('allow', '');     // prefix filter (e.g. "192.168."), empty = allow all
const VERBOSE = args.includes('--verbose') || args.includes('-v');

const wss = new WebSocketServer({ port: WS_PORT, host: WS_HOST });
console.log(`[bridge] Listening on ws://${WS_HOST}:${WS_PORT}`);
if (ALLOW) console.log(`[bridge] Restricting target host prefix to: "${ALLOW}"`);

wss.on('connection', (ws, req) => {
  const q = url.parse(req.url, true).query;
  const targetHost = q.host;
  const targetPort = parseInt(q.port, 10) || 502;
  const peer = req.socket.remoteAddress;
  const tag = `[${peer} → ${targetHost}:${targetPort}]`;

  if (!targetHost) {
    ws.send('Error: missing ?host= query parameter');
    ws.close();
    return;
  }
  if (ALLOW && !String(targetHost).startsWith(ALLOW)) {
    ws.send(`Error: target host "${targetHost}" not in allowed prefix "${ALLOW}"`);
    ws.close();
    return;
  }

  console.log(`${tag} WS open`);

  const tcp = net.createConnection({ host: targetHost, port: targetPort });
  tcp.on('connect', () => {
    if (VERBOSE) console.log(`${tag} TCP connected`);
  });
  tcp.on('data', (buf) => {
    if (ws.readyState === 1) ws.send(buf);
    if (VERBOSE) console.log(`${tag} TCP→WS ${buf.length} bytes`);
  });
  tcp.on('error', (err) => {
    if (ws.readyState === 1) ws.send('TCP error: ' + err.message);
    console.log(`${tag} TCP error: ${err.message}`);
  });
  tcp.on('close', () => {
    if (ws.readyState === 1) ws.close();
    console.log(`${tag} TCP closed`);
  });

  ws.on('message', (msg, isBinary) => {
    if (!isBinary) {
      // Ignore text messages for now (could implement control protocol)
      return;
    }
    if (tcp.writable) {
      tcp.write(msg);
      if (VERBOSE) console.log(`${tag} WS→TCP ${msg.length} bytes`);
    }
  });
  ws.on('close', () => {
    if (tcp.writable) tcp.destroy();
    console.log(`${tag} WS closed`);
  });
});

process.on('SIGINT', () => {
  console.log('\n[bridge] Shutting down...');
  wss.close(() => process.exit(0));
});
