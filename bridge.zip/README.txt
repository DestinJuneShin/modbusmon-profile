Modbus TCP WebSocket Bridge
============================

This little Node.js script lets the browser PWA talk to Modbus TCP
devices. The browser cannot open raw TCP sockets, so it speaks WebSocket
to this bridge, which forwards bytes to a real TCP socket on your behalf.


Prerequisites
-------------
  - Node.js 18 or newer.  Get it from https://nodejs.org


First-time setup (one-time)
---------------------------
  Windows :  double-click  start-bridge.bat
             It will install the 'ws' library, then start the bridge.
             ("Setup complete" is printed once when this happens.)

  Other OS:  cd into this folder, run:
                 npm install
                 node tcp-bridge.js


Run the bridge (after first-time setup)
---------------------------------------
  Windows :  double-click  start-bridge.bat   (same file, install is skipped)
  Other   :  node tcp-bridge.js

The bridge listens on ws://127.0.0.1:8765 by default and waits for the
browser to connect. Leave the console window open — closing it stops
the bridge.


Options
-------
  node tcp-bridge.js --port 9000           Listen on a different port
  node tcp-bridge.js --bind 0.0.0.0        Allow LAN clients (see below)
  node tcp-bridge.js --allow 192.168.      Restrict target IPs by prefix
  node tcp-bridge.js -v                    Verbose log (byte counts)


Browser side
------------
In the PWA, set the top bar to:
  Transport     : TCP (WebSocket bridge)
  Bridge        : ws://localhost:8765
  Target host   : <device IP>
  Port          : 502
Then click Connect.


Security note
-------------
By default the bridge listens on 127.0.0.1 only — same PC as your
browser. This is the safest setup.

If you change --bind to 0.0.0.0 (LAN exposure), ALWAYS combine with
--allow to restrict target IPs. Otherwise anyone on the LAN can use
your PC to reach any TCP host:port pair.
