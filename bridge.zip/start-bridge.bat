@echo off
REM ============================================================
REM  Modbus TCP WebSocket Bridge launcher
REM
REM  First run installs the 'ws' npm dependency, then starts the
REM  bridge in the same window. Re-run any time to start again.
REM ============================================================
setlocal
cd /d "%~dp0"
title Modbus TCP Bridge

REM --- Check Node.js / npm ---
where node >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Node.js was not found in PATH.
    echo         Install it from https://nodejs.org/  ^(LTS recommended^)
    echo         then re-run this file.
    echo.
    pause
    exit /b 1
)

REM --- First-time setup: install 'ws' ---
REM IMPORTANT: 'call' is required when invoking another .bat / .cmd
REM (npm is npm.cmd on Windows). Without 'call', control would not
REM return to this script and the bridge would never start.
if not exist node_modules (
    echo.
    echo First-time setup: installing the 'ws' WebSocket library...
    echo This only happens once.
    echo.
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERROR] npm install failed. See messages above.
        echo         Possible causes:
        echo           - No internet connection
        echo           - Corporate proxy not configured for npm
        echo           - Antivirus blocking %%APPDATA%%\npm-cache
        echo.
        pause
        exit /b 1
    )
    echo.
    echo Setup complete.
    echo.
)

REM --- Start the bridge ---
echo ============================================================
echo  Bridge listening on  ws://127.0.0.1:8765
echo  Press Ctrl+C  to stop.
echo ============================================================
echo.
node tcp-bridge.js

REM If node exits (e.g. Ctrl+C), pause so the user can read the
REM final output before the window closes.
echo.
pause
endlocal
